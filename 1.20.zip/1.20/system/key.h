#ifndef _KEY_H_
#define _KEY_H_


void key_init();


#endif